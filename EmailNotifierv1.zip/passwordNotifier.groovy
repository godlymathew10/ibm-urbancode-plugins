import com.urbancode.air.AirPluginTool;
import com.datamato.emailnotifier.PasswordShare;

def apTool = new AirPluginTool(this.args[0], this.args[1])

/* Here we call getStepProperties() to get a Properties object that contains the step properties
 * provided by the user.
 */
def props = apTool.getStepProperties();

// get the user, password, and weburl needed to create a rest client
def udUser = apTool.getAuthTokenUsername();
def udAuth = apTool.getAuthToken();
def udWebURL = System.getenv("AH_WEB_URL");

//Defining PasswordShare Class Object;
def passwordNotifier = new PasswordShare()
passwordNotifier.passwordSpliter(props,udUser,udAuth,udWebURL);

//Set an output property
apTool.setOutputProperty("outPropName", "outPropValue");
apTool.storeOutputProperties();//write the output properties to the file
