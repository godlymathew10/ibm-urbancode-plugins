import com.urbancode.air.AirPluginTool;
import com.datamato.vCenter.RequestClusterResourceAvailability;

def apTool = new AirPluginTool(this.args[0], this.args[1])

/* Here we call getStepProperties() to get a Properties object that contains the step properties
 * provided by the user.
 */
def props = apTool.getStepProperties();

/* This is how you retrieve properties from the object. You provide the "name" attribute of the
 * <property> element
 *
 */
def requestClusterResourceAvailability = new RequestClusterResourceAvailability();
def clusterResoucreList = requestClusterResourceAvailability.RequestResourceAvailability(props);

println"${clusterResoucreList}"

//Set an output property
apTool.setOutputProperty("outPropName", "outPropValue");
apTool.setOutputProperty("ClusterResourceList",clusterResoucreList.toString());

//write the output properties to the file
apTool.storeOutputProperties();